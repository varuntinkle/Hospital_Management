# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('database', '0003_patient_image'),
    ]

    operations = [
        migrations.AddField(
            model_name='doctor',
            name='image',
            field=models.TextField(blank=True),
        ),
    ]
