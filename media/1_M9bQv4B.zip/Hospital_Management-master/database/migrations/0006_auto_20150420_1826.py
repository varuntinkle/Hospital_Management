# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('database', '0005_auto_20150420_1500'),
    ]

    operations = [
        migrations.AlterField(
            model_name='doctor',
            name='image',
            field=models.ImageField(upload_to=b'Doctors'),
        ),
        migrations.AlterField(
            model_name='patient',
            name='image',
            field=models.ImageField(upload_to=b'Patients'),
        ),
    ]
