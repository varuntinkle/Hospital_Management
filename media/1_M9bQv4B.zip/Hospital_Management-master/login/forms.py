from database import models
from django.contrib.auth.models import User
from django import forms
from django.contrib.auth import forms as UserForms

class DoctorForm(forms.Form):
    username = forms.CharField(label="User name")
    password = forms.CharField(label="Password")
    name = forms.CharField(label="Name")
    speciality = forms.CharField(label="Speciality")
    qualification = forms.CharField(label="Qualification")
    image = forms.ImageField(label="Choose Image")
