from django.contrib import admin
from database.models import Post

# Register your models here.

admin.site.register(Post)
