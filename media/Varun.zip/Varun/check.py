import os,fnmatch,re,shutil

def location(location, t1, c):
	#print location
	#location = "index.php@sub=62&brch=176&sim=1151&cnt=2680.html"
	f1=open(location,'r+')
	f2 = open("location.txt","a")
	text = f1.read()
	m1 = re.search('(<title>)([^<]*)(</title>)',text)
	if m1:
		x1 = m1.group(2)
		a1 = x1.split(" : ")
		a1 = a1[::-1]
		l1 = ""
		for i in a1:
			l1 = l1+'/'+i
		#print location,l1
		
		l1 = "."+l1
		if not os.path.exists(l1):
    			#print l1
    			os.makedirs(l1)
    	l1 = l1+'/'+ location
    	if c==0:
			shutil.copy(location, l1)
	if c==1:
		os.rename(location, l1)
	l1=l1[1:]
	l1="/home/varun/Downloads/iitg.vlab.co.in"+l1
	f2.write("%s %s \n"%(location,l1))
	t1[location]=l1
	#print l1 	`


	

def javascript(location):
	f=open(location,'r')
	text = f.read()
	text = text.replace("js","/home/varun/Downloads/iitg.vlab.co.in/js")
	text = text.replace("theme","/home/varun/Downloads/iitg.vlab.co.in/theme")
	text = text.replace("images/bulb.gif","/home/varun/Downloads/iitg.vlab.co.in/images/bulb.gif")
	text = text.replace("images/temp.gif","/home/varun/Downloads/iitg.vlab.co.in/images/temp.gif")
	text = text.replace("images/seperator_line.png","/home/varun/Downloads/iitg.vlab.co.in/images/seperator_line.png")
	text = text.replace("fckeditor","/home/varun/Downloads/iitg.vlab.co.in/fckeditor")
	text = text.replace("captcha","/home/varun/Downloads/iitg.vlab.co.in/captcha")
	f1 = open(location,'w')
	f1.write("%s"%(text))



def link(location,t1):
	#location = 'index.html@sub=58.html'
	f1=open(location,'r')
	text = f1.read()
	#print text
	s1=""
	for keys in t1:
		s1=keys.replace("&","&amp;")
		if text.find(s1) !=-1:

			if  text[text.find(s1)-6:text.find(s1)-2] =='href':
				if   text[text.find(s1)+len(s1)]!='@':
					if   text[text.find(s1)+len(s1)]!='&':
						if   text[text.find(s1)+len(s1)]!='&amp;':
							#print s1, t1[keys]

							text=text.replace(s1,t1[keys].replace("&","&amp;"))
				#print "Hi", text
				#text=s1
			#print textpython
			#text=s1
	
	f2=open(location,'w')
	f2.write("%s"%(text))
	javascript(location)
	
def main():

	t1={}
	for file in os.listdir("."):
		if file.endswith(".html") and file !="check1.html":
			#print file
			location(file,t1,0)
	#link("Hi", t1)
	#/home/varun/Downloads/iitg.vlab.co.in/IIT GUWAHATI Virtual Lab
	for file in os.listdir("."):
		if file.endswith('.html'):
			link(file, t1)

	for file in os.listdir("."):
		if file.endswith(".html") and file !="check1.html":
			#print file
			location(file,t1,1) 
	
		
	











if __name__ == '__main__':
	main()
