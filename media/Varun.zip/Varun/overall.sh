python links.py
python dead_links.py
python check.py
