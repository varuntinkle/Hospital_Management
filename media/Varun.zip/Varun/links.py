import os,re



def main():
	for x in os.listdir("."):
		f2=open("wget.txt",'a')
		if x.endswith(".html"):
			f1=open(x,'r')
			text1=f1.read()
			m1=re.findall("http://iitg.vlab.co.in[^<]*userfiles[^<]*.png",text1)
			m1=m1+re.findall("http://iitg.vlab.co.in[^<]*userfiles[^<]*.jpg",text1)
			m1=m1+re.findall("http://iitg.vlab.co.in[^<]*userfiles[^<]*.gif",text1)
			m1=m1+re.findall("http://iitg.vlab.co.in[^<]*userfiles[^<]*.swf",text1)
			m1=m1+re.findall("http://iitg.vlab.co.in[^<]*userfiles [^<]*.JPG",text1)
			if m1:
				for k in m1:
					f2.write("%s\n"%(k))





if __name__ == '__main__':
	main()






#youtube-dl --proxy https://r.varun:haveaniceday5081nexus@202.141.80.24:3128 https://www.youtube.com/embed/zyhdIYW70tI
