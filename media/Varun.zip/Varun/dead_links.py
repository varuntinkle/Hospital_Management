import urllib2,re,urllib,os

proxy_info = {
'user' : 'r.varun',
'pass' : 'haveaniceday5081nexus',
'host' : "202.141.80.24",
'port' : 3128 # or 8080 or whatever
}

# build a new opener that uses a proxy requiring authorization
proxy_support = urllib2.ProxyHandler({"http" : \
"http://%(user)s:%(pass)s@%(host)s:%(port)d" % proxy_info})
opener = urllib2.build_opener(proxy_support, urllib2.HTTPHandler)

# install it
urllib2.install_opener(opener)

# use it



def link_working(webpage):
	try:
		urllib2.urlopen(webpage)
		return 1
	except:
		return 0

def check(location):
	#location = "index.html@sub=58&brch=160&sim=1324&cnt=2790.html"
	print location
	f1=open(location,"r")
	text=f1.read()
	links = re.findall('<a href="?\'?([^"\'>]*)', text)
	for link in links:
		if link[:4]=='http':
			#print link
			#if link_working(link)==0:
			text = text.replace(link,"/home/varun/Downloads/iitg.vlab.co.in/Internet.html")
	f2=open(location,"w")
	f2.write("%s"%(text))
    	

def main():
	for file in os.listdir("."):
		if file.endswith(".html"):
			check(file)




if __name__ == '__main__':
	main()
